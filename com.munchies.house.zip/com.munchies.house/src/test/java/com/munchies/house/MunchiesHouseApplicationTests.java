package com.munchies.house;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MunchiesHouseApplicationTests {

	@Test
	void contextLoads() {
	}

}

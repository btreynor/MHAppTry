package com.munchies.house;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MunchiesHouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(MunchiesHouseApplication.class, args);
	}

}
